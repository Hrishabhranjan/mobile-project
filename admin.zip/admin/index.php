<?php	
  $url = 'admin_home.php';
?>
<meta http-equiv='refresh' content='0;url=<?php echo $url; ?>'>
